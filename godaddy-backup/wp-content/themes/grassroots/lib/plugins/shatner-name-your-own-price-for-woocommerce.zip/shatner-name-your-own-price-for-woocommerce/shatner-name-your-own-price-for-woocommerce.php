<?php
/*
Plugin Name: WooCommerce - Name your own price
Plugin URI: https://blog.seanvoss.com/product/shatner
Description: Allows users to set their own price (can also be used for donations) 
Version: 1.9
Author: Sean Voss
Author URI: http://seanvoss.com/

*/

/*
 * Title   : WooCommerce Name your own price
 * Author  : Sean Voss
 * URL     : https://blog.seanvoss.com/product/shatner
 * License : https://github.com/seanvoss/shatner/LICENSEE
 */

function sv_name_price_wc_init() 
{


   // Order of Plugin Loading Requires this line, should not be necessary
   require_once (dirname(__FILE__) .'/../woocommerce/woocommerce.php');

    /**
     * Check if WooCommerce is active
     **/
    if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
        include_once('name_price_wc_plugin.php');
    }
}

add_action('plugins_loaded', 'sv_name_price_wc_init', 10);
