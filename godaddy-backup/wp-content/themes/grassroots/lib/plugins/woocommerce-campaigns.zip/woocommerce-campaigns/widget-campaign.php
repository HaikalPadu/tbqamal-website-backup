<?php
/**
 * Campaign Widget
 *
 * Displays a campaign's information, featured image
 * and progress  
 *
 */

class CampaignWidget extends WP_Widget {
  /**
  * Declares the CampaignWidget class.
  *
  */
    function __construct() {
    $widget_ops = array('classname' => 'campign-widget', 'description' => esc_html__( 'Displays the campaign of your choosing.','woocommerce-campaigns') );
    parent::__construct('campaign-widget', esc_html__('Campaign Widget','woocommerce-campaigns'), $widget_ops);
    }

  /**
    * Displays the Widget
    *
    */
    function widget($args, $instance){
      extract($args);
      $title = empty($instance['title']) ? '' : $instance['title'];
      $campaign = empty($instance['campaign']) ? '' : $instance['campaign'];
      $cart = empty($instance['cart']) ? '' : $instance['cart'];

      # Before the widget
      echo $before_widget;

      # Make the widget
      
            	
      	
      	
      	$args = array( 
      		'post_type' => 'product',
      		'p' => $campaign
      		);
      	
      	$campaign_display = new WP_Query( $args );
      	
      	while($campaign_display->have_posts()) : $campaign_display->the_post(); ?>
      		
      		<?php if ( has_post_thumbnail() ) { ?>
      			
      			<div class="campaign-image">
      			
      				<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php echo esc_attr( sprintf( esc_html__( 'Permalink to %s', 'woocommerce-campaigns' ), the_title_attribute( 'echo=0' ) ) ); ?>"><?php the_post_thumbnail( '', array( 'class' => 'feature' ) ); ?></a>
      			
      			</div>
      		
	      		<div class="campaign-widget-content campaign-has-image">
	      	
	      	<?php } else { // no featured image ?>
	      	
	      		<div class="campaign-widget-content campaign-no-image">
	      		      	    		      	
	      	<?php } ?>
	      			
	      			<?php if (!empty($instance['title'])) { ?>
	      			
	      				<a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php echo esc_attr( sprintf( esc_html__( 'Permalink to %s', 'woocommerce-campaigns' ), the_title_attribute( 'echo=0' ) ) ); ?>">
	      				
	      				<?php echo $before_title . apply_filters('widget_title', $instance['title']) . $after_title ; ?>
	      				
	      				</a>
	      			
	      			 <?php } ?>
	      			 
		      		<?php the_excerpt(); ?>
		      		
		      		<?php campaign_progress_bar(); ?>
		      		
		      		<?php if (!empty($instance['cart'])) { ?>
		      		    	
		      			<a class="button" href="<?php the_permalink(); ?>" rel="bookmark" title="<?php echo esc_attr( sprintf( esc_html__( '%s', 'woocommerce-campaigns' ), the_title_attribute( 'echo=0' ) ) ); ?>"><?php echo $cart ?></a>
	      			
	      			<?php } ?>
	      			
	      		</div><!-- .campaign-widget-content -->
      		
      	<?php endwhile; wp_reset_query(); 

      # After the widget
      echo $after_widget;
  }

  /**
    * Saves the widget's settings.
    *
    */
    function update($new_instance, $old_instance){
      $instance = $old_instance;
      $instance['title'] = stripslashes($new_instance['title']);
      $instance['campaign'] = stripslashes($new_instance['campaign']);
      $instance['cart'] = stripslashes($new_instance['cart']);

    return $instance;
  }

  /**
    * Creates the edit form for the widget.
    *
    */
    function form($instance){
      //Defaults
      $instance = wp_parse_args( (array) $instance, array(
      		'title' => '',
      		'campaign' => '',
      		'cart' => 'Donate'
      	) 
      );


?>
	
	<p>
		<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'woocommerce-campaigns'); ?>:</label>
		<input type="text" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo esc_attr( $instance['title'] ); ?>" style="width:95%;" />
	</p>

	<p>
		<label for="<?php echo $this->get_field_id( 'campaign' ); ?>"><?php _e( 'Campaign', 'woocommerce-campaigns' ); ?>:</label>
		<select style="width: 100%;" id="<?php echo $this->get_field_id( 'campaign' ); ?>" name="<?php echo $this->get_field_name( 'campaign' ); ?>">		
	
			<?php $args = array( 
						'post_type' => 'product', 
						'posts_per_page' => '-1', 
						'orderby'=>'menu_order', 
						'order'=>'ASC',
						'meta_query' => array(
							array(
								'key' => '_is_campaign',
								'value' => 'yes',
							),
						), 
				);
				
			$loop = new WP_Query( $args ); ?>
			<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>
				
				<option value="<?php the_ID(); ?>" <?php if ( $instance['campaign'] == get_the_ID() ) echo 'selected="selected"'; ?>><?php the_title(); ?></option>
	
			<?php endwhile; wp_reset_query(); ?>
				
		        	
		</select>
	</p>
    	
	<p>
		<label for="<?php echo $this->get_field_id('cart'); ?>"><?php _e('Button Label', 'woocommerce-campaigns'); ?>:</label>
		<input type="text" id="<?php echo $this->get_field_id('cart'); ?>" name="<?php echo $this->get_field_name('cart'); ?>" value="<?php echo esc_attr( $instance['cart'] ); ?>" style="width:95%;" />
	</p>
    
<?php
  }

}// END class

	function CampaignWidget_Init() {
		register_widget('CampaignWidget');
	}
	add_action('widgets_init', 'CampaignWidget_Init');
