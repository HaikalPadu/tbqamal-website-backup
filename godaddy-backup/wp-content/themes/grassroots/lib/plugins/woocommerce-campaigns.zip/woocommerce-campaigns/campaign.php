<?php

/*
 * This file creates our new campaign tab in the product editor
 * and adds the fields for the campaign function
 *
 *
*/
	
	if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


	// Sets the version of the plugin so we can use it later
		define( 'CAMPAIGN_VERSION', '1.0.6' );

	
	// determine the amount of revenue for the current product
		function organizedtheme_campaign_revenue() {
		
			// from http://imdev.in/woocommerce-how-to-get-total-sales-of-all-products-number/
			
			global $wpdb;
			
				$order_items = apply_filters( 'woocommerce_reports_top_earners_order_items', $wpdb->get_results( "
						SELECT order_item_meta_2.meta_value as product_id, SUM( order_item_meta.meta_value ) as line_total FROM {$wpdb->prefix}woocommerce_order_items as order_items
				
						LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
						LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta_2 ON order_items.order_item_id = order_item_meta_2.order_item_id
						LEFT JOIN {$wpdb->posts} AS posts ON order_items.order_id = posts.ID
						
				
						WHERE   posts.post_type     = 'shop_order'
						AND     posts.post_status   IN ( '" . implode( "','", array( 'wc-completed', 'wc-processing', 'wc-on-hold' ) ) . "' )
						AND 	order_items.order_item_type = 'line_item'
						AND 	order_item_meta.meta_key = '_line_total'
						AND 	order_item_meta_2.meta_key = '_product_id'
						GROUP BY order_item_meta_2.meta_value
					" ));
			
			return $order_items;	
			
		}


	// add campign tab to product data in WooCommerce
		function organizedthemes_campaign_tab() {
		
			echo '<li class="custom_tab"><a href="#campaign_tab_data">' . esc_html__('Campaign', 'woocommerce-campaigns' ). '</a></li>';
		
		}
		
		add_action('woocommerce_product_write_panel_tabs', 'organizedthemes_campaign_tab');
	
		
	// add fields to new tab
		function organizedthemes_campaign_tab_content() {
		
		      echo '<div id="campaign_tab_data" class="panel woocommerce_options_panel">';
		      	
		      		global $woocommerce, $post;
		      		
		      		echo '<div class="options_group">';
		      		  
		      		  woocommerce_wp_checkbox( 
	      			    array( 
	      			    	'id'            => '_is_campaign', 
	      			    	'label'         => esc_html__('Campaign', 'woocommerce-campaigns' ), 
	      			    	'desc_tip'		=> 'true',
	      			    	'description'   => esc_html__( 'Checking this box makes this a campaign "product."', 'woocommerce-campaigns' ) 
						)
					);
		      		  
	      			woocommerce_wp_text_input( 
	      				array( 
	      					'id'			=> '_campaign_goal', 
	      					'label'			=> esc_html__( 'Campaign Goal', 'woocommerce-campaigns' ), 
	      					'placeholder'	=> '',
	      					'desc_tip'		=> 'true',
	      					'description'	=> esc_html__( 'Enter the goal of your campaign here.', 'woocommerce-campaigns' ),
	      					'type'			=> 'number'
	      				)
	      			);
	      			
	      			woocommerce_wp_text_input( 
	      				array( 
	      					'id'			=> '_campaign_button_text', 
	      					'label'			=> esc_html__( 'Add To Cart Button Text', 'woocommerce-campaigns' ), 
	      					'placeholder'	=> 'Give',
	      					'desc_tip'		=> 'true',
	      					'description'	=> esc_html__( 'Enter the text you\'d like to have on the add to cart button.', 'woocommerce-campaigns' )
	      				)
	      			);
	      			
	      			woocommerce_wp_text_input( 
	      				array( 
	      					'id'			=> '_campaign_join_text', 
	      					'label'			=> esc_html__( 'Raised Of Text', 'woocommerce-campaigns' ), 
	      					'placeholder'	=> 'Raised Of',
	      					'desc_tip'		=> 'true',
	      					'description'	=> esc_html__( 'This is the text that goes between the amount raised and the goal.', 'woocommerce-campaigns' )
	      				)
	      			);
		      			
	      			$order_items = organizedtheme_campaign_revenue();
	      			
	      			foreach ($order_items as $item) {
	      				
	      				$product_ID = array(get_the_ID());
	      				
	      			    if ( in_array($item->product_id, $product_ID) ) {
	      			
	      			        $total_given = $item->line_total;
	      					
	      					echo '<p> '.esc_html__( 'Total Given', 'woocommerce-campaigns' ).' <strong>';
	      					
	      					echo get_woocommerce_currency_symbol();
	      					
	      					echo $total_given;
	      					
	      					echo '</strong></p>';
	      					
	      			    }
	      			
	      			}
		      			
		      		organizedthemes_display_campaign();
		      			
				echo '</div>';
		      	
			echo '</div>';	
				
		}
		
		add_action('woocommerce_product_data_panels', 'organizedthemes_campaign_tab_content');	
		
		
		
	// save fields
		function woo_add_custom_general_fields_save( $post_id ){
			
			$woocommerce__is_campaign = isset( $_POST['_is_campaign'] ) ? 'yes' : 'no';
				update_post_meta( $post_id, '_is_campaign', $woocommerce__is_campaign );
				
			$woocommerce_campaign_goal = $_POST['_campaign_goal'];
				if( !empty( $woocommerce_campaign_goal ) )
					update_post_meta( $post_id, '_campaign_goal', esc_attr( $woocommerce_campaign_goal ) );
			
			$woocommerce_campaign_button_text = $_POST['_campaign_button_text'];
				if( !empty( $woocommerce_campaign_button_text ) )
					update_post_meta( $post_id, '_campaign_button_text', esc_attr( $woocommerce_campaign_button_text ) );
			
			$woocommerce_campaign_join_text = $_POST['_campaign_join_text'];
				if( !empty( $woocommerce_campaign_join_text ) )
					update_post_meta( $post_id, '_campaign_join_text', esc_attr( $woocommerce_campaign_join_text ) );
			
		}
		
		add_action( 'woocommerce_process_product_meta', 'woo_add_custom_general_fields_save' );
	
	// Add hook for widget progress display
		function campaign_progress_bar() {
			do_action( 'campaign_progress_bar' );
		}
		
	
	// display progress on front end
		function organizedthemes_display_campaign() {
			
			global $post;

			if ( get_post_meta($post->ID, "_is_campaign", $single = true) == "yes"  ) {
				
				$campaign_goal = get_post_meta($post->ID, "_campaign_goal", TRUE);
				
				$goal = number_format($campaign_goal);
				$join_text = get_post_meta($post->ID, "_campaign_join_text", TRUE);
				$symbol = get_woocommerce_currency_symbol();
				
				echo '
				
				<div class="organizedthemes-campaign-holder">
				
					';
					
					$order_items = organizedtheme_campaign_revenue();
					
					if ( $order_items != true ) {
						
						echo '
												
							<div class="campaign-total">
							
								<h3>'. $symbol .'0</h3>
								<p>
									<span class="join-text"> '.$join_text.' </span>
									<span class="goal-value">'. $symbol, $goal,  esc_html__( ' goal', 'woocommerce-campaigns' ).'</span>
								</p>
								
							</div>
							
							<div class="graph-holder">
							
								<div class="graph-progress" style="width: 0%;"></div>
								
								<span class="progress-number">0%</span>
								
							</div>
	
							
						';
						
					
					} else {
					
						$total_given = 0;
						
						foreach ($order_items as $item) {
							
							$product_ID = array(get_the_ID());
							
						    if (in_array($item->product_id, $product_ID)) {
						
						        $total_given = $item->line_total;
						        
						        $display_total_given = number_format($total_given);
								
								$progress_full = $total_given / $campaign_goal * 100;
								
								$progress = round($progress_full, 0);
								
								echo '
									
									<div class="campaign-total">
									
										<h3>'. $symbol, $display_total_given .'</h3>
										<p>
											<span class="join-text"> '.$join_text.' </span>
											<span class="goal-value">'. $symbol, $goal,  esc_html__( ' goal', 'woocommerce-campaigns' ).'</span>
										</p>
										
									</div>
									
									<div class="graph-holder">
									
										<div class="graph-progress" style="width: '.$progress.'%;"></div>
										
										<span class="progress-number"> '.$progress, '%</span>
										
									</div>
			
									
								';
								
								
							} else {		
								
							}	
	    
						
						}
						
					}
					
					
				echo '	
				</div>
				
				';
			
			} // if ( get_post_meta($post->ID, "_is_campaign", $single = true) == "yes"  )
		
		}
		
		add_action('woocommerce_single_product_summary', 'organizedthemes_display_campaign', 25);
		add_action('campaign_progress_bar', 'organizedthemes_display_campaign', 25);
	
	
	// change add to cart text if is campaign
		function organizedthemes_change_campaign_button( $text = '' , $post = '' ) {
			
			global $product, $post;
			
			if ( ( get_post_meta($post->ID, "_is_campaign", $single = true) == "yes"  ) && ( get_post_meta($post->ID, "_campaign_button_text", $single = true) != ""  ) ) {
			
				$text = get_post_meta($post->ID, "_campaign_button_text", TRUE);
			
			}
		
			return $text;
			
		 
		}
		add_filter('woocommerce_product_single_add_to_cart_text', 'organizedthemes_change_campaign_button', 2, 10); 
	
	
	// Load Stylesheet for frontend
		function organizedthemes_campaign_styles() {
		
			wp_enqueue_style( 'organizedthemes-campaigns', plugins_url( 'assets/campaigns.css', __FILE__ ), false, CAMPAIGN_VERSION, 'screen' );
		
		}
		add_action( 'wp_enqueue_scripts', 'organizedthemes_campaign_styles'  );
		
		
	// Load Stylesheet for admin
		function organizedthemes_campaign_admin_style( $page ) {
		
			wp_enqueue_style( 'campaign-admin', plugins_url('assets/campaign-admin.css', __FILE__) );
		
		}
		add_action( 'admin_enqueue_scripts', 'organizedthemes_campaign_admin_style' );
	
	
	// Load plugin updater
		function organizedthemes_campaign_updater_init() {
		
			/* Load Plugin Updater */
			require_once( trailingslashit( plugin_dir_path( __FILE__ ) ) . 'includes/plugin-updater.php' );
		
			/* Updater Config */
			$config = array(
				'base'      => plugin_basename( __FILE__ ), //required
				'dashboard' => false,
				'username'  => false,
				'key'       => '',
				'repo_uri'  => 'http://support.organizedthemes.com/',  //required
				'repo_slug' => 'campaign-plugin',  //required
			);
		
			/* Load Updater Class */
			new OrganizedThemes_Campaign_Updater( $config );
		}
		
		add_action( 'init', 'organizedthemes_campaign_updater_init' );
