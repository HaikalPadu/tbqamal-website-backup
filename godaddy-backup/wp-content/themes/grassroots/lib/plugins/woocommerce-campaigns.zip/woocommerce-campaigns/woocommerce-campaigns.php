<?php
/*
Plugin Name: WooCommerce - Campaigns
Plugin URI: https://www.organizedthemes.com/campaign-extension-for-woocommerce-plugin/
Description: Raise money and show your progress with WooCommerce 
Version: 1.0.6
Author: Organized Themes
Author URI: https://www.organizedthemes.com/

*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

function organizedthemes_woo_campaigns() {

	// is woocommerce active  
		if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
			include_once('campaign.php');
			include_once('widget-campaign.php');
		}
	
	// load text domain
		load_plugin_textdomain( 'woocommerce-campaigns', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
    
}

add_action('plugins_loaded', 'organizedthemes_woo_campaigns', 10);